import InputTracker



def writeFile(file_contents):
    write_file = "./trackingres.txt"
    file = open(write_file, "w")
    file.write(file_contents)
    file.close()

tracker = InputTracker.InputTracker()
tracker.startTracking(writeFile,track_mouse=True, track_keyboard=True, print_events=True)
